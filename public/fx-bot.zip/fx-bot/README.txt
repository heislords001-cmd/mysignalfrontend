FX Desk bot (runs on YOUR Windows PC)

Before you start
- A Windows PC that stays on while the bot runs
- MetaTrader 5 installed and logged in to your broker account (start with a DEMO account, hedging type)
- Python 3.11 or newer (tick "Add to PATH" when installing)

Steps
1. Rename env.example to .env and fill in FX_EMAIL and FX_PASSWORD (your FX Desk login), then MT5_LOGIN, MT5_PASSWORD and MT5_SERVER.
   If your broker's pair names have a letter added (like EURUSDm), fill in MT5_SUFFIX.
2. Open a terminal in this folder and run: pip install -r requirements.txt
3. Run: python bot.py
4. On the site, open the Bot tab and press Turn bot on.

Your MT5 password stays on your PC. The bot only sends your trades and balance to your own page on the site.
Keep TRADING_MODE=demo until you trust it. Trading carries risk and you can lose money.
